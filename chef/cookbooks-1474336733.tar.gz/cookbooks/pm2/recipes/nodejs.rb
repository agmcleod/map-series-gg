#
# Cookbook Name:: pm2
# Recipe:: nodejs
#
# Copyright 2015, Mindera
#

# Install nodejs
include_recipe 'nodejs'
