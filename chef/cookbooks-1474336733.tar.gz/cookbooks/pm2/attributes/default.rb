#
# Cookbook Name:: pm2
# Attributes:: default
#
# Copyright 2015, Mindera
#

default_unless['pm2']['version'] = 'latest'
