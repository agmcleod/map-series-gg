name 'nodejs_local'

depends 'apt'
depends 'nodejs', '~> 2.4.4'