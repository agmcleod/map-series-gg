nodejs_npm 'npm' do
  version '3.9.5'
end